%%%����SQP�㷨�������Թ滮��Ҫ��Ŀ�꺯���Կ�����U���ݶȣ�����Ҫ״̬���̺������ȷ���
function dx2=defineode2(t,x2,u2,p)
% dx = [u; 1];  %original ode is x_dot =u, the sensitive equation dx/du =1 with initial value 0
global N
dx2 = zeros(4+4*N,1);  %4 states+10 components of constraint gradient, i.e., dx1/dp1,dx1/dp2, since path constraint only
                   %contains x1, calculating gradients of x1 wrt,
                   %p1,...,p10 is enough

Kl=0.006;
mu=0.11;
Yxs=0.47;
theta=0.004;
Yp=1.2;
Ki=0.1;
Mx=0.029;
Kxp=0.01;
Kp=0.0001;
S0=400;


dx2(1)=mu*x2(1)*x2(2)/(Kl*x2(1)+x2(2))-u2*x2(1)/x2(4);  %define ode
dx2(2)=-mu*x2(1)*x2(2)/(Yxs*(Kl*x2(1)+x2(2)))-theta*x2(1)*x2(2)/(Yp*(x2(2)+Kp+x2(2)^2/Ki))-Mx*x2(1)+u2*(S0-x2(2))/x2(4);
dx2(3)=theta*x2(1)*x2(2)/(x2(2)+Kp+x2(2)^2/Ki)-Kxp*x2(3)-u2*x2(3)/x2(4);
dx2(4)=u2;

for i=1:N
    if i==p
        DX11=mu*x2(2)^2/(Kl*x2(1)+x2(2))^2-u2/x2(4);
        DX12=mu*Kl*x2(1)^2/(Kl*x2(1)+x2(2))^2;
        DX14=u2*x2(1)/x2(4)^2;
    dx2(4*i+1)=DX11*x2(4*i+1)+DX12*x2(4*i+2)+DX14*x2(4*i+4)-x2(1)/x2(4);     %dx1/dp1,..., dx1/dp10
        DX21=-mu*x2(2)^2/(Yxs*(Kl*x2(1)+x2(2))^2)-theta*x2(2)/(Yp*(x2(2)+Kp+x2(2)^2/Ki))-Mx;
        DX22=-mu*x2(1)^2*Kl/(Yxs*(Kl*x2(1)+x2(2))^2)-theta*x2(1)*(Kp-x2(2)^2/Ki)/(Yp*(x2(2)+Kp+x2(2)^2/Ki)^2)-u2/x2(4);
        DX24=-u2*(S0-x2(2))/x2(4)^2;
    dx2(4*i+2)=DX21*x2(4*i+1)+DX22*x2(4*i+2)+DX24*x2(4*i+4)+(S0-x2(2))/x2(4);      %dx2/dp1,..., dx2/dp10
        DX31=theta*x2(2)/(x2(2)+Kp+x2(2)^2/Ki);
        DX32=theta*x2(1)*(Kp-x2(2)^2/Ki)/(x2(2)+Kp+x2(2)^2/Ki)^2;
        DX33=-Kxp-u2/x2(4);
        DX34=u2*x2(3)/x2(4)^2;
    dx2(4*i+3)=DX31*x2(4*i+1)+DX32*x2(4*i+2)+DX33*x2(4*i+3)+DX34*x2(4*i+4)-x2(3)/x2(4);      %dx2/dp1,..., dx2/dp10
    dx2(4*i+4)=1;
    
    else
        DX11=mu*x2(2)^2/(Kl*x2(1)+x2(2))^2-u2/x2(4);
        DX12=mu*Kl*x2(1)^2/(Kl*x2(1)+x2(2))^2;
        DX14=u2*x2(1)/x2(4)^2;
    dx2(4*i+1)=DX11*x2(4*i+1)+DX12*x2(4*i+2)+DX14*x2(4*i+4);     %dx1/dp1,..., dx1/dp10
        DX21=-mu*x2(2)^2/(Yxs*(Kl*x2(1)+x2(2))^2)-theta*x2(2)/(Yp*(x2(2)+Kp+x2(2)^2/Ki))-Mx;
        DX22=-mu*x2(1)^2*Kl/(Yxs*(Kl*x2(1)+x2(2))^2)-theta*x2(1)*(Kp-x2(2)^2/Ki)/(Yp*(x2(2)+Kp+x2(2)^2/Ki))^2-u2/x2(4);
        DX24=-u2*(S0-x2(2))/x2(4)^2;
    dx2(4*i+2)=DX21*x2(4*i+1)+DX22*x2(4*i+2)+DX24*x2(4*i+4);      %dx2/dp1,..., dx2/dp10
        DX31=theta*x2(2)/(x2(2)+Kp+x2(2)^2/Ki);
        DX32=theta*x2(1)*(Kp-x2(2)^2/Ki)/(x2(2)+Kp+x2(2)^2/Ki)^2;
        DX33=-Kxp-u2/x2(4);
        DX34=u2*x2(3)/x2(4)^2;
    dx2(4*i+3)=DX31*x2(4*i+1)+DX32*x2(4*i+2)+DX33*x2(4*i+3)+DX34*x2(4*i+4);      %dx2/dp1,..., dx2/dp10
    dx2(4*i+4)=0;
    end
    
end