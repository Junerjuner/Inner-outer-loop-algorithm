function y2 = defineobjfun2(x2,u2)   %Ŀ�꺯��Ϊ: min X23+lambda_l*A2*x2+(p/2)*norm(u2_k-u2bar_l)*Sigma_2
global u2bar lambda
Sigma_2=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);A2=[0 0 0 -1];pho=0.8;
y2 = -x2(end,3)+lambda*A2*(x2(end,1:4))'+(pho/2)*(u2-u2bar)'*Sigma_2*(u2-u2bar);  %define cost function
end