%%%����SQP�㷨�������Թ滮��Ҫ��Ŀ�꺯���Կ�����U���ݶȣ�����Ҫ״̬���̺������ȷ���
function dx1=defineode1(t,x1,u1,p)
% dx = [u; 1];  %original ode is x_dot =u, the sensitive equation dx/du =1 with initial value 0
global N
dx1 = zeros(4+4*N,1);  %4 states+10 components of constraint gradient, i.e., dx1/dp1,dx1/dp2, since path constraint only
                   %contains x1, calculating gradients of x1 wrt,
                   %p1,...,p10 is enough

Kl=0.006;
mu=0.11;
Yxs=0.47;
theta=0.004;
Yp=1.2;
Ki=0.1;
Mx=0.029;
Kxp=0.01;
Kp=0.0001;
S0=400;


dx1(1)=mu*x1(1)*x1(2)/(Kl*x1(1)+x1(2))-u1*x1(1)/x1(4);  %define ode
dx1(2)=-mu*x1(1)*x1(2)/(Yxs*(Kl*x1(1)+x1(2)))-theta*x1(1)*x1(2)/(Yp*(x1(2)+Kp+x1(2)^2/Ki))-Mx*x1(1)+u1*(S0-x1(2))/x1(4);
dx1(3)=theta*x1(1)*x1(2)/(x1(2)+Kp+x1(2)^2/Ki)-Kxp*x1(3)-u1*x1(3)/x1(4);
dx1(4)=u1;

for i=1:N
    if i==p
        DX11=mu*x1(2)^2/(Kl*x1(1)+x1(2))^2-u1/x1(4);
        DX12=mu*Kl*x1(1)^2/(Kl*x1(1)+x1(2))^2;
        DX14=u1*x1(1)/x1(4)^2;
    dx1(4*i+1)=DX11*x1(4*i+1)+DX12*x1(4*i+2)+DX14*x1(4*i+4)-x1(1)/x1(4);     %dx1/dp1,..., dx1/dp10
        DX21=-mu*x1(2)^2/(Yxs*(Kl*x1(1)+x1(2))^2)-theta*x1(2)/(Yp*(x1(2)+Kp+x1(2)^2/Ki))-Mx;
        DX22=-mu*x1(1)^2*Kl/(Yxs*(Kl*x1(1)+x1(2))^2)-theta*x1(1)*(Kp-x1(2)^2/Ki)/(Yp*(x1(2)+Kp+x1(2)^2/Ki)^2)-u1/x1(4);
        DX24=-u1*(S0-x1(2))/x1(4)^2;
    dx1(4*i+2)=DX21*x1(4*i+1)+DX22*x1(4*i+2)+DX24*x1(4*i+4)+(S0-x1(2))/x1(4);      %dx2/dp1,..., dx2/dp10
        DX31=theta*x1(2)/(x1(2)+Kp+x1(2)^2/Ki);
        DX32=theta*x1(1)*(Kp-x1(2)^2/Ki)/(x1(2)+Kp+x1(2)^2/Ki)^2;
        DX33=-Kxp-u1/x1(4);
        DX34=u1*x1(3)/x1(4)^2;
    dx1(4*i+3)=DX31*x1(4*i+1)+DX32*x1(4*i+2)+DX33*x1(4*i+3)+DX34*x1(4*i+4)-x1(3)/x1(4);      %dx2/dp1,..., dx2/dp10
    dx1(4*i+4)=1;
    
    else
        DX11=mu*x1(2)^2/(Kl*x1(1)+x1(2))^2-u1/x1(4);
        DX12=mu*Kl*x1(1)^2/(Kl*x1(1)+x1(2))^2;
        DX14=u1*x1(1)/x1(4)^2;
    dx1(4*i+1)=DX11*x1(4*i+1)+DX12*x1(4*i+2)+DX14*x1(4*i+4);     %dx1/dp1,..., dx1/dp10
        DX21=-mu*x1(2)^2/(Yxs*(Kl*x1(1)+x1(2))^2)-theta*x1(2)/(Yp*(x1(2)+Kp+x1(2)^2/Ki))-Mx;
        DX22=-mu*x1(1)^2*Kl/(Yxs*(Kl*x1(1)+x1(2))^2)-theta*x1(1)*(Kp-x1(2)^2/Ki)/(Yp*(x1(2)+Kp+x1(2)^2/Ki))^2-u1/x1(4);
        DX24=-u1*(S0-x1(2))/x1(4)^2;
    dx1(4*i+2)=DX21*x1(4*i+1)+DX22*x1(4*i+2)+DX24*x1(4*i+4);      %dx2/dp1,..., dx2/dp10
        DX31=theta*x1(2)/(x1(2)+Kp+x1(2)^2/Ki);
        DX32=theta*x1(1)*(Kp-x1(2)^2/Ki)/(x1(2)+Kp+x1(2)^2/Ki)^2;
        DX33=-Kxp-u1/x1(4);
        DX34=u1*x1(3)/x1(4)^2;
    dx1(4*i+3)=DX31*x1(4*i+1)+DX32*x1(4*i+2)+DX33*x1(4*i+3)+DX34*x1(4*i+4);      %dx2/dp1,..., dx2/dp10
    dx1(4*i+4)=0;
    end
    
end