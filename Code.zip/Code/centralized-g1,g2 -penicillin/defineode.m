%%%����SQP�㷨�������Թ滮��Ҫ��Ŀ�꺯���Կ�����U���ݶȣ�����Ҫ״̬���̺������ȷ���
function dx=defineode(t,x,u1,u2,PFS)%Ŀ�꺯������״̬���̣������ȡ�nonlinear and dynamic optimization ��177ҳ State and Sensitivity Numerical Integration״̬����������ֵ���
global N

dx = zeros(8+16*N,1);  %3 states+10 components of constraint gradient, i.e., dx1/dp1,dx1/dp2, since path constraint only contains x1, 
                      %calculating gradients of x1 wrt p1,...,p10 is enough, 
Kl=0.006;
mu=0.11;
Yxs=0.47;
theta=0.004;
Yp=1.2;
Ki=0.1;
Mx=0.029;
Kxp=0.01;
Kp=0.0001;
S0=400;

dx(1)=mu*x(1)*x(2)/(Kl*x(1)+x(2))-u1*x(1)/x(4);  %define ode
dx(2)=-mu*x(1)*x(2)/(Yxs*(Kl*x(1)+x(2)))-theta*x(1)*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx*x(1)+u1*(S0-x(2))/x(4);
dx(3)=theta*x(1)*x(2)/(x(2)+Kp+x(2)^2/Ki)-Kxp*x(3)-u1*x(3)/x(4);
dx(4)=u1;
dx(5)=mu*x(5)*x(6)/(Kl*x(5)+x(6))-u2*x(5)/x(8);  %define ode
dx(6)=-mu*x(5)*x(6)/(Yxs*(Kl*x(5)+x(6)))-theta*x(5)*x(6)/(Yp*(x(6)+Kp+x(6)^2/Ki))-Mx*x(5)+u2*(S0-x(6))/x(8);
dx(7)=theta*x(5)*x(6)/(x(6)+Kp+x(6)^2/Ki)-Kxp*x(7)-u2*x(7)/x(8);
dx(8)=u2;

for i=1:N  
    if i==PFS  %p��pathconstraints�е�PFS��Ҳ����ÿһ�ηֶ�i=1��N
        DX11=mu*x(2)^2/(Kl*x(1)+x(2))^2-u1/x(4);
        DX12=mu*Kl*x(1)^2/(Kl*x(1)+x(2))^2;
        DX14=u1*x(1)/x(4)^2;
    dx(16*i-7)=DX11*x(16*i-7)+DX12*x(16*i-5)+DX14*x(16*i-1)-x(1)/x(4);%dx(1)��u1     % df/dx*dx/du+df/dui(i=1,2,3,4,5,6,7,8,9,10)     
    dx(16*i-6)=DX11*x(16*i-6)+DX12*x(16*i-4)+DX14*x(16*i);%dx(1)��u2
        DX21=-mu*x(2)^2/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx;
        DX22=-mu*x(1)^2*Kl/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(1)*(Kp-x(2)^2/Ki)/(Yp*(x(2)+Kp+x(2)^2/Ki)^2)-u1/x(4);
        DX24=-u1*(S0-x(2))/x(4)^2;
    dx(16*i-5)=DX21*x(16*i-7)+DX22*x(16*i-5)+DX24*x(16*i-1)+(S0-x(2))/x(4);%dx(2)��u1     
    dx(16*i-4)=DX21*x(16*i-6)+DX22*x(16*i-4)+DX24*x(16*i); %dx(2)��u2
        DX31=theta*x(2)/(x(2)+Kp+x(2)^2/Ki);
        DX32=theta*x(1)*(Kp-x(2)^2/Ki)/(x(2)+Kp+x(2)^2/Ki)^2;
        DX33=-Kxp-u1/x(4);
        DX34=u1*x(3)/x(4)^2;
    dx(16*i-3)=DX31*x(16*i-7)+DX32*x(16*i-5)+DX33*x(16*i-3)+DX34*x(16*i-1)-x(3)/x(4); %dx(3)��u1
    dx(16*i-2)=DX31*x(16*i-6)+DX32*x(16*i-4)+DX33*x(16*i-2)+DX34*x(16*i); %dx(3)��u2
    dx(16*i-1)=1; %dx(4)��u1
    dx(16*i)=0;%dx(4)��u2
        DX51=mu*x(6)^2/(Kl*x(5)+x(6))^2-u2/x(8);
        DX52=mu*Kl*x(5)^2/(Kl*x(5)+x(6))^2;
        DX54=u2*x(5)/x(8)^2;
    dx(16*i+1)=DX51*x(16*i+1)+DX52*x(16*i+3)+DX54*x(16*i+7);%dx(5)��u1
    dx(16*i+2)=DX51*x(16*i+2)+DX52*x(16*i+4)+DX54*x(16*i+8)-x(5)/x(8);%dx(5)��u2
        DX61=-mu*x(6)^2/(Yxs*(Kl*x(5)+x(6))^2)-theta*x(5)/(Yp*(x(6)+Kp+x(6)^2/Ki))-Mx;
        DX62=-mu*x(5)^2*Kl/(Yxs*(Kl*x(5)+x(6))^2)-theta*x(5)*(Kp-x(6)^2/Ki)/(Yp*(x(6)+Kp+x(6)^2/Ki)^2)-u2/x(8);
        DX64=-u2*(S0-x(6))/x(8)^2;
    dx(16*i+3)=DX61*x(16*i+1)+DX62*x(16*i+3)+DX64*x(16*i+7);%dx(6)��u1     
    dx(16*i+4)=DX61*x(16*i+2)+DX62*x(16*i+4)+DX64*x(16*i+8)+(S0-x(6))/x(8); %dx(6)��u2
        DX71=theta*x(6)/(x(6)+Kp+x(6)^2/Ki);
        DX72=theta*x(5)*(Kp-x(6)^2/Ki)/(x(6)+Kp+x(6)^2/Ki)^2;
        DX73=-Kxp-u2/x(8);
        DX74=u2*x(7)/x(8)^2;
    dx(16*i+5)=DX71*x(16*i+1)+DX72*x(16*i+3)+DX73*x(16*i+5)+DX74*x(16*i+7); %dx(7)��u1
    dx(16*i+6)=DX71*x(16*i+2)+DX72*x(16*i+4)+DX73*x(16*i+6)+DX74*x(16*i+8)-x(7)/x(8); %dx(7)��u2
    dx(16*i+7)=0; %dx(8)��u1
    dx(16*i+8)=1; %dx(8)��u2
    else
        DX11=mu*x(2)^2/(Kl*x(1)+x(2))^2-u1/x(4);
        DX12=mu*Kl*x(1)^2/(Kl*x(1)+x(2))^2;
        DX14=u1*x(1)/x(4)^2;
    dx(16*i-7)=DX11*x(16*i-7)+DX12*x(16*i-5)+DX14*x(16*i-1);%dx(1)��u1     % df/dx*dx/du+df/dui(i=1,2,3,4,5,6,7,8,9,10)     
    dx(16*i-6)=DX11*x(16*i-6)+DX12*x(16*i-4)+DX14*x(16*i);%dx(1)��u2
        DX21=-mu*x(2)^2/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx;
        DX22=-mu*x(1)^2*Kl/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(1)*(Kp-x(2)^2/Ki)/(Yp*(x(2)+Kp+x(2)^2/Ki)^2)-u1/x(4);
        DX24=-u1*(S0-x(2))/x(4)^2;
    dx(16*i-5)=DX21*x(16*i-7)+DX22*x(16*i-5)+DX24*x(16*i-1);%dx(2)��u1     
    dx(16*i-4)=DX21*x(16*i-6)+DX22*x(16*i-4)+DX24*x(16*i); %dx(2)��u2
        DX31=theta*x(2)/(x(2)+Kp+x(2)^2/Ki);
        DX32=theta*x(1)*(Kp-x(2)^2/Ki)/(x(2)+Kp+x(2)^2/Ki)^2;
        DX33=-Kxp-u1/x(4);
        DX34=u1*x(3)/x(4)^2;
    dx(16*i-3)=DX31*x(16*i-7)+DX32*x(16*i-5)+DX33*x(16*i-3)+DX34*x(16*i-1); %dx(3)��u1
    dx(16*i-2)=DX31*x(16*i-6)+DX32*x(16*i-4)+DX33*x(16*i-2)+DX34*x(16*i); %dx(3)��u2
    dx(16*i-1)=0; %dx(4)��u1
    dx(16*i)=0;%dx(4)��u2
        DX51=mu*x(6)^2/(Kl*x(5)+x(6))^2-u2/x(8);
        DX52=mu*Kl*x(5)^2/(Kl*x(5)+x(6))^2;
        DX54=u2*x(5)/x(8)^2;
    dx(16*i+1)=DX51*x(16*i+1)+DX52*x(16*i+3)+DX54*x(16*i+7);%dx(5)��u1
    dx(16*i+2)=DX51*x(16*i+2)+DX52*x(16*i+4)+DX54*x(16*i+8);%dx(5)��u2
        DX61=-mu*x(6)^2/(Yxs*(Kl*x(5)+x(6))^2)-theta*x(5)/(Yp*(x(6)+Kp+x(6)^2/Ki))-Mx;
        DX62=-mu*x(5)^2*Kl/(Yxs*(Kl*x(5)+x(6))^2)-theta*x(5)*(Kp-x(6)^2/Ki)/(Yp*(x(6)+Kp+x(6)^2/Ki)^2)-u2/x(8);
        DX64=-u2*(S0-x(6))/x(8)^2;
    dx(16*i+3)=DX61*x(16*i+1)+DX62*x(16*i+3)+DX64*x(16*i+7);%dx(6)��u1     
    dx(16*i+4)=DX61*x(16*i+2)+DX62*x(16*i+4)+DX64*x(16*i+8); %dx(6)��u2
        DX71=theta*x(6)/(x(6)+Kp+x(6)^2/Ki);
        DX72=theta*x(5)*(Kp-x(6)^2/Ki)/(x(6)+Kp+x(6)^2/Ki)^2;
        DX73=-Kxp-u2/x(8);
        DX74=u2*x(7)/x(8)^2;
    dx(16*i+5)=DX71*x(16*i+1)+DX72*x(16*i+3)+DX73*x(16*i+5)+DX74*x(16*i+7); %dx(7)��u1
    dx(16*i+6)=DX71*x(16*i+2)+DX72*x(16*i+4)+DX73*x(16*i+6)+DX74*x(16*i+8); %dx(7)��u2
    dx(16*i+7)=0; %dx(8)��u1
    dx(16*i+8)=0; %dx(8)��u2   
    end
end









