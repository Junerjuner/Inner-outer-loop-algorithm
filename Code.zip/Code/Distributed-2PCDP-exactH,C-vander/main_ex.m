close all;
clc;
clear;
global u1bar u2bar lambda 
u1bar=0.3*[1;1;1;1;1;1;1;1;1;1];
u2bar=0.3*[1;1;1;1;1;1;1;1;1;1];
lambda=3;
Kmax=20;
fan=[];
lam=[];
Fun=[];
CC1=[];
DD=[];
A1=[0 1 0];
A2=[0 -1 0];
b=0;
pho=1;
Sigma_1=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);
Sigma_2=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);
U11=zeros(Kmax,10);
U21=zeros(Kmax,10);
Lam1=zeros(Kmax,1);
H=cputime;
for k=0:Kmax
[T_UBD1,M1,miu1,X1,x1,u1,multi1_PCDP,Gc1,GC1_ex,h1]=state1;
[T_UBD2,M2,miu2,X2,x2,u2,multi2_PCDP,Gc2,GC2_ex,h2]=state2;
%     a1=abs(A1*X1(1:3)'+A2*X2(1:3)'-b);
%     b1=pho*norm(Sigma_1*(u1-u1bar),1);
%     b2=pho*norm(Sigma_2*(u2-u2bar),1);
%
% figure(6)%目标函数图
% % axisVec=['(',num2str(k),',',num2str(F1),')'];%生成坐标点的字符串
% % text( k, F1, axisVec );%在指定的坐标位置显示字符串数据
% F1=X1(3)+X2(3);
% Fun=[Fun;F1];
% hold on;
% plot(k,F1,'o','MarkerEdgeColor',[0 0.45 0.74],'MarkerFaceColor',[0 0.45 0.74],'markersize',6);
% hold on;
% line([0 20],[6.015005631605712 6.015005631605712],'linestyle','-','Color',[0.85 0.33 0.1],'LineWidth',1);
% hold on;
% plot([14,14],[5.5,8.5],'linestyle','--','Color',[0.85 0.33 0.1],'LineWidth',1);
% axis([0 20 5.5 8.5]);
% set(gca,'XTick',0:5:20);
% set(gca,'YTick',5.5:0.5:8.5);
% box on;
% xlabel({'$l$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% ylabel({'$x_{13} \left( {t_f ,u_1 } \right) + x_{23} \left( {t_f ,u_2 } \right)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% legend({['distributed objective' newline 'function values'],['centralized objective' newline 'function value'],'$l=14$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
 %%
% figure(7)%收敛速度图
% u1bar_local=U11(end,:);
% u2bar_local=U21(end,:);
% lambda_local=Lam1(end,1);
% U1=[0.3*[1;1;1;1;1;1;1;1;1;1]';U11(1:end-1,:)];
% U2=[0.3*[1;1;1;1;1;1;1;1;1;1]';U21(1:end-1,:)];
% Lam=[3;Lam1(1:end-1)];
% D=zeros(21,1);
% for k=1:21
% D(k)=log10(1*norm(U1(k,:)-u1bar_local+U2(k,:)-u2bar_local,inf)+1*norm(Lam(k,1)-lambda_local,inf));
% end
% fan=[];
% fan=[fan;D];
% hold on;
% plot(0:20,D,'o','markersize',6,'LineWidth',1,'color',[0 0.45 0.74]);
% hold on;
% plot([14,14],[-6,1],'linestyle','--','Color',[0.85 0.33 0.1],'LineWidth',1);
% axis([0 20 -6 1]);
% set(gca,'XTick',0:5:20);
% set(gca,'YTick',-6:1:1);
% box on;
% xlabel({'$l$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% % ylabel({'$\log _{10} \left\| {u - u^ *  } \right\|_\infty$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal'); 
% ylabel({'$\log _{10} \left( {\chi _1 \left\| {u - u*} \right\|_\infty   + \chi _2 \left\| {\lambda  - \lambda *} \right\|_\infty  } \right)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% legend({'$\log _{10} \left( {\chi _1 \left\| {u - u*} \right\|_\infty   + \chi _2 \left\| {\lambda  - \lambda *} \right\|_\infty  } \right)$','$l=14$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% %% 
figure(3)%耦合约束图
% axisVec=['(',num2str(k),',',num2str(CC),')'];%生成坐标点的字符串
% text( k, CC, axisVec );%在指定的坐标位置显示字符串数据
CC=A1*X1(1:3)'+A2*X2(1:3)'-b;
CC1=[CC1;CC];
hold on;
plot(k, CC, '*','markersize',8,'LineWidth',1,'color',[0.85 0.33 0.1]); %plot maximumizer
hold on;
plot([0,20],[0,0],'m--','LineWidth',1);
hold on;
plot([14,14],[-2,1],'linestyle','--','Color',[0.85 0.33 0.1],'LineWidth',1);
axis([0 20 -2 1]);
set(gca,'XTick',0:5:20);
set(gca,'YTick',-2:0.5:1);
box on;
xlabel({'$l$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
ylabel({'$A_1x_1+A_2x_2-b$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
legend({'$A_1x_1+A_2x_2-b$','$A_1x_1+A_2x_2-b=0$','$l=14$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
%%
if ((abs(A1*X1(1:3)'+A2*X2(1:3)'-b)<=1e-8)&&(pho*norm(Sigma_1*(u1-u1bar),1)<=1e-8)&&(pho*norm(Sigma_2*(u2-u2bar),1)<=1e-8))==1%终止条件
    u1bar_local=u1;
    u2bar_local=u2;
    lambda=lambda;
%     break;%取消break时，阈值为1e-8
else
    [delta_u1,delta_u2,LAMBDA,s]=QP_ex;%调用QP
    u1bar=u1+delta_u1;
    u2bar=u2+delta_u2;
    lambda=LAMBDA; 
    s;
k=k+1; 
    Lam1(k,:)=lambda;
    U11(k,:)=u1bar;
    U21(k,:)=u2bar;
end
end
t=0:20;
hold on; plot(t,CC1)

lambda;
k;
F1=X1(3)+X2(3);
TIME=cputime-H;
%%
% [Gmax1,Tmax1,t1out,x1out] = LLP_events1(u1,k);
% [Gmax2,Tmax2,t2out,x2out] = LLP_events2(u2,k);
% g1=-x1out(:,1)-0.4;%路径约束是要求g<=0
% g2=-x2out(:,1)-0.42;%路径约束是要求g<=0
% figure(4)%路径约束图
% hold on
% plot(t1out,g1(:,1),'b-','LineWidth',1.5,'color',[0.301 0.745 0.933]);         %plot g wrt t for the ith time subinterval，
% plot(t2out,g2(:,1),'g-','LineWidth',1.5,'color',[0.466 0.674 0.188]);         %plot g wrt t for the ith time subinterval，
% plot(t1out,g1(:,1)-g1(:,1),'m--','LineWidth',1.5); %plot a horizen line（地平线） at g=0  
% xlabel({'$t$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% ylabel({'$g_i(x_i,u_i,t)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% box on
% axis([0 5 -0.5 0.1]);
% set(gca,'XTick',0:0.5:5);
% set(gca,'YTick',-0.5:0.1:0.1);
% plot(Tmax1, Gmax1, 'rp','MarkerFaceColor','r','markersize',8); %plot maximumizer%'MarkerFaceColor','r'----将空心五角星填充颜色变为红色%'markersize',8-----将空心五角星的大小设置为8
% plot(Tmax2, Gmax2, 'rp','MarkerFaceColor','r','markersize',8); %plot maximumizer%'MarkerFaceColor','r'----将空心五角星填充颜色变为红色%'markersize',8-----将空心五角星的大小设置为8
% axisVec1=['(',num2str(Tmax1),',',num2str(Gmax1),')'];%生成坐标点的字符串
% axisVec2=['(',num2str(Tmax2),',',num2str(Gmax2),')'];%生成坐标点的字符串
% text( Tmax1, Gmax1, axisVec1 );%在指定的坐标位置显示字符串数据
% text( Tmax2, Gmax2, axisVec2 );%在指定的坐标位置显示字符串数据
% legend({'$g_1(x_1,u_1,t)$','$g_2(x_2,u_2,t)$','$g_i(x_i,u_i,t)=0$','max$g_i(x_i,u_i,t)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% %%
% u11bar_local=[u1bar_local;u1bar_local(10)];
% u22bar_local=[u2bar_local;u2bar_local(10)];
% t=0:0.5:5;
% figure(50)%控制输入图
% stairs(t,u11bar_local,'r-','LineWidth',2,'color',[0.85 0.33 0.1]);
% hold on;
% stairs(t,u22bar_local,'b-','LineWidth',2,'color',[0 0.45 0.74]);
% axis([0 5 -0.2 1.2]);
% set(gca,'XTick',0:0.5:5);
% set(gca,'YTick',-0.2:0.2:1.2);
% xlabel({'$t$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% ylabel({'$u_i(t)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
% box on;
% % hold off;
% legend({'$u_1(t)$','$u_2(t)$'},'Interpreter','latex','FontSize',12,'FontWeight','Normal');
