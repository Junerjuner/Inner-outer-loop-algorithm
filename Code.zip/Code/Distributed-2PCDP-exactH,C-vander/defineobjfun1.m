function y1 = defineobjfun1(x1,u1)   %Ŀ�꺯��Ϊ: min X13+lambda_l*A1*x1+(p/2)*norm(u1_k-u1bar_l)*Sigma_1
global u1bar lambda 
Sigma_1=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);A1=[0 1 0];pho=1;
y1 = x1(end,3)+lambda*A1*(x1(end,1:3))'+(pho/2)*(u1-u1bar)'*Sigma_1*(u1-u1bar);  %define cost function, which is the end element of the first column
end
