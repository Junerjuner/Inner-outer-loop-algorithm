function dxx2=defineodexx2(t,xx2,u2,PFS)
global N
dxx2=zeros(3+3*N+3*N*N,1);

dxx2(1)=(1-xx2(2)^2)*xx2(1)-xx2(2)+u2;
dxx2(2) = xx2(1); 
dxx2(3)= xx2(1)^2+xx2(2)^2+u2^2;

for i=1:N  %dx(1)/du=x(3*i+1)��ʾx��u��;dx(3*i+1)=d(dx(1))/du ��ʾx(1)_dot��u��=d(x(1)_dot)/du=d(dx(1))/dx*dx/du+d(dx(1))/dui(dx�е�x����[xx1 x2 x3]) 
   for j=1:N  %dx(1)/du=x(3*i+1)��ʾx��u��;dx(3*i+1)=d(dx(1))/du ��ʾx(1)_dot��u��=d(x(1)_dot)/du=d(dx(1))/dx*dx/du+d(dx(1))/dui(dx�е�x����[xx1 x2 x3])     
    if i==PFS  %pathconstraints�е�PFS��Ҳ����ÿһ�ηֶ�i=1��N
            dxx2(3*i+1)=(1-xx2(2)^2)*xx2(3*i+1)+(-2*xx2(2)*xx2(1)-1)*xx2(3*i+2)+1;     % df/dx*dx/du+df/dui(i=1,2,3,4,5,6,7,8,9,10)     
            dxx2(3*i+2)=1*xx2(3*i+1);     
            dxx2(3*i+3)=2*xx2(1)*xx2(3*i+1)+2*xx2(2)*xx2(3*i+2)+2*u2; 
            
          if j==PFS
                dxx2(30*j+3*i+1)=-2*xx2(2)*xx2(3*j+2)*xx2(3*i+1)-2*xx2(2)*xx2(3*j+1)*xx2(3*i+2)-2*xx2(1)*xx2(3*j+2)*xx2(3*i+2)+(1-xx2(2)^2)*xx2(30*j+3*i+1)+(-2*xx2(1)*xx2(2)-1)*xx2(30*j+3*i+2);
                dxx2(30*j+3*i+2)=xx2(30*j+3*i+1);
                dxx2(30*j+3*i+3)=2*xx2(3*j+1)*xx2(3*i+1)+2*xx2(3*j+2)*xx2(3*i+2)+2*xx2(1)*xx2(30*j+3*i+1)+2*xx2(2)*xx2(30*j+3*i+2)+2;
            else
                dxx2(30*j+3*i+1)=-2*xx2(2)*xx2(3*j+2)*xx2(3*i+1)-2*xx2(2)*xx2(3*j+1)*xx2(3*i+2)-2*xx2(1)*xx2(3*j+2)*xx2(3*i+2)+(1-xx2(2)^2)*xx2(30*j+3*i+1)+(-2*xx2(1)*xx2(2)-1)*xx2(30*j+3*i+2);
                dxx2(30*j+3*i+2)=xx2(30*j+3*i+1);
                dxx2(30*j+3*i+3)=2*xx2(3*j+1)*xx2(3*i+1)+2*xx2(3*j+2)*xx2(3*i+2)+2*xx2(1)*xx2(30*j+3*i+1)+2*xx2(2)*xx2(30*j+3*i+2);
          end

    else
            dxx2(3*i+1)=(1-xx2(2)^2)*xx2(3*i+1)+(-2*xx2(2)*xx2(1)-1)*xx2(3*i+2);    % df/dx*dx/du+df/duj(j=1,2,3,4,i-1,i+1,7,8,9,10) 
            dxx2(3*i+2)=1*xx2(3*i+1);     
            dxx2(3*i+3)=2*xx2(1)*xx2(3*i+1)+2*xx2(2)*xx2(3*i+2); 
             if j==PFS
                dxx2(30*j+3*i+1)=-2*xx2(2)*xx2(3*j+2)*xx2(3*i+1)-2*xx2(2)*xx2(3*j+1)*xx2(3*i+2)-2*xx2(1)*xx2(3*j+2)*xx2(3*i+2)+(1-xx2(2)^2)*xx2(30*j+3*i+1)+(-2*xx2(1)*xx2(2)-1)*xx2(30*j+3*i+2);
                dxx2(30*j+3*i+2)=xx2(30*j+3*i+1);
                dxx2(30*j+3*i+3)=2*xx2(3*j+1)*xx2(3*i+1)+2*xx2(3*j+2)*xx2(3*i+2)+2*xx2(1)*xx2(30*j+3*i+1)+2*xx2(2)*xx2(30*j+3*i+2);
            else
                dxx2(30*j+3*i+1)=-2*xx2(2)*xx2(3*j+2)*xx2(3*i+1)-2*xx2(2)*xx2(3*j+1)*xx2(3*i+2)-2*xx2(1)*xx2(3*j+2)*xx2(3*i+2)+(1-xx2(2)^2)*xx2(30*j+3*i+1)+(-2*xx2(1)*xx2(2)-1)*xx2(30*j+3*i+2);
                dxx2(30*j+3*i+2)=xx2(30*j+3*i+1);
                dxx2(30*j+3*i+3)=2*xx2(3*j+1)*xx2(3*i+1)+2*xx2(3*j+2)*xx2(3*i+2)+2*xx2(1)*xx2(30*j+3*i+1)+2*xx2(2)*xx2(30*j+3*i+2);
            end
     end
   end


 end
end


