function [delta_u1,delta_u2,LAMBDA,s]=QP_ex
global lambda
% global u1bar u2bar 
% u1bar=0.3*[1;1;1;1;1;1;1;1;1;1];
% u2bar=0.3*[1;1;1;1;1;1;1;1;1;1];
% lambda=0;
A1=[0 1 0];
A2=[0 -1 0];
b=0;
N=10;
T=5; 
% pho=1;
% Sigma_1=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);
% Sigma_2=diag(0.1*[1;1;1;1;1;1;1;1;1;1],0);
%%
[T_UBD1,M1,miu1,X1,x1,u1,multi1_PCDP,Gc1,GC1_ex,h1]=state1;
i=1:N;
G1=x1(end,3*i+3)';% exact jacobian
%%求hessain，因为不等式约束有路径约束和框约束，框约束求2阶导为0，所以不等式约束只考虑路径约束就行
%这里取exact hessian
Init_val_sensi_equ = zeros(1,3*N); %3 is the dimension of system, need to intialize the senstivity equs
Init_val_sensi_equ_2order = zeros(1,3*N*N);
xx1_0=[0 1 0 Init_val_sensi_equ Init_val_sensi_equ_2order];
yy1_0=xx1_0;  %pass the intial value of states 传递状态的初始值
for i = 1:N  %每进行一次循环，x的值全部更新一次，也就是说，在每个分段上x的值是不一样的
    [t,xx1]=ode45(@(t,xx1) defineodexx1(t,xx1,u1(i),i),[(i-1)*T/N, i*T/N],yy1_0);%i=1时，x1-x6被计算出来,x7至x33=0;|||i=2时，x1-x9被计算出来，x10至x33=0,原来的数会发生变化。第二、三、四次之后进来PFS=10保留原来第一次的10不变，所以i=10时，x的值只有x1至x3和x31至x33有数值
yy1_0=xx1(end,:);
end
XX1=xx1(end,:);
Temp13 = XX1(3+3*N+3:3:3+3*N+3*N*N);
H31 = reshape(Temp13,N,N);
H31=(H31+H31')/2;

%%
[T_UBD2,M2,miu2,X2,x2,u2,multi2_PCDP,Gc2,GC2_ex,h2]=state2;
i=1:N;
G2=x2(end,3*i+3)';%jacobian

Init_val_sensi_equ = zeros(1,3*N); %3 is the dimension of system, need to intialize the senstivity equs
Init_val_sensi_equ_2order = zeros(1,3*N*N);
xx2_0=[0 1 0 Init_val_sensi_equ Init_val_sensi_equ_2order];
yy2_0=xx2_0;  %pass the intial value of states 传递状态的初始值
for i = 1:N  %每进行一次循环，x的值全部更新一次，也就是说，在每个分段上x的值是不一样的
    [t,xx2]=ode45(@(t,xx2) defineodexx2(t,xx2,u2(i),i),[(i-1)*T/N, i*T/N],yy2_0);%i=1时，x1-x6被计算出来,x7至x33=0;|||i=2时，x1-x9被计算出来，x10至x33=0,原来的数会发生变化。第二、三、四次之后进来PFS=10保留原来第一次的10不变，所以i=10时，x的值只有x1至x3和x31至x33有数值
yy2_0=xx2(end,:);
end
XX2=xx2(end,:);
Temp23 = XX2(3+3*N+3:3:3+3*N+3*N*N);
H32 = reshape(Temp23,N,N);
H32=(H32+H32')/2;




gamma=1;
H0=zeros(N,N);
s0=zeros(1,N);
C10=zeros(h1,N);% numel(T_UBD)=M;故此时的g1是M*1维；
C20=zeros(h2,N);
b10=zeros(h1,1);% numel(T_UBD)=M;
b20=zeros(h2,1);
% delta_u=[delta_u1;delta_u2;s];
H=[H31,H0,s0';H0,H32,s0';s0,s0,gamma];
G=[G1;G2;lambda];
gradX1=[X1(4:3:31);X1(5:3:32);X1(6:3:33)];% 因为X1_new=X1+gradX1*delta_u1;
gradX2=[X2(4:3:31);X2(5:3:32);X2(6:3:33)];% X2_new=X2+gradX2*delta_u2;
C1=GC1_ex(1:N,1:h1)';
C2=GC2_ex(1:N,1:h2)';
Aeq=[C1,C10,b10;C20,C2,b20;A1*gradX1,A2*gradX2,-1];
beq=[b10;b20;-A1*X1(1:3)'-A2*X2(1:3)'+b];
[delta_u,fval,exitflag,output,lambda]=quadprog(H,G,[],[],Aeq,beq);%默认使用options中的interior-point-convex algorithm
U=delta_u;
delta_u1=U(1:10,1);
delta_u2=U(11:20,1);
s=U(end,1);
f_QP=fval;
LAMBDA=lambda.eqlin(end,1);
end